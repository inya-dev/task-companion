import { 
  reminders, 
  categories, 
  userStats, 
  completedReminders,
  type Reminder, 
  type InsertReminder,
  type Category,
  type InsertCategory,
  type UserStats,
  type InsertUserStats,
  type CompletedReminder,
  type InsertCompletedReminder,
  type Suggestion
} from "@shared/schema";

export interface IStorage {
  // Reminders
  getReminders(): Promise<Reminder[]>;
  getRemindersByCategory(category: string): Promise<Reminder[]>;
  getReminder(id: number): Promise<Reminder | undefined>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  updateReminder(id: number, reminder: Partial<InsertReminder>): Promise<Reminder | undefined>;
  deleteReminder(id: number): Promise<boolean>;
  completeReminder(id: number): Promise<boolean>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // User Stats
  getUserStats(): Promise<UserStats>;
  updateUserStats(stats: Partial<InsertUserStats>): Promise<UserStats>;
  incrementCompletedToday(): Promise<UserStats>;
  
  // Completed Reminders
  getCompletedReminders(): Promise<CompletedReminder[]>;
  addCompletedReminder(reminder: InsertCompletedReminder): Promise<CompletedReminder>;
  
  // AI Suggestions
  getSuggestions(): Promise<Suggestion[]>;
}

export class MemStorage implements IStorage {
  private reminders: Map<number, Reminder>;
  private categories: Map<number, Category>;
  private userStatsData: UserStats;
  private completedRemindersData: Map<number, CompletedReminder>;
  private currentReminderId: number;
  private currentCategoryId: number;
  private currentCompletedId: number;

  constructor() {
    this.reminders = new Map();
    this.categories = new Map();
    this.completedRemindersData = new Map();
    this.currentReminderId = 1;
    this.currentCategoryId = 1;
    this.currentCompletedId = 1;
    
    this.userStatsData = {
      id: 1,
      completedToday: 0,
      streak: 0,
      totalCompleted: 0,
      lastCompletionDate: null,
    };

    // Initialize default categories
    this.initializeCategories();
    this.initializeSampleReminders();
  }

  private initializeCategories() {
    const defaultCategories: InsertCategory[] = [
      { name: "Health & Fitness", icon: "fas fa-heartbeat", color: "neon-green" },
      { name: "Work & Career", icon: "fas fa-briefcase", color: "neon-purple" },
      { name: "Personal Growth", icon: "fas fa-user", color: "neon-yellow" },
      { name: "Social & Family", icon: "fas fa-users", color: "neon-blue" },
    ];

    defaultCategories.forEach(cat => {
      const category: Category = { ...cat, id: this.currentCategoryId++ };
      this.categories.set(category.id, category);
    });
  }

  private initializeSampleReminders() {
    const sampleReminders: InsertReminder[] = [
      {
        title: "Morning Workout Session",
        description: "30-minute cardio and strength training",
        category: "Health & Fitness",
        priority: "medium",
        dueDate: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes from now
        repeat: "daily",
      },
      {
        title: "Review Project Proposal",
        description: "Final review of Q4 marketing proposal",
        category: "Work & Career",
        priority: "high",
        dueDate: new Date(Date.now() - 24 * 60 * 60 * 1000), // Yesterday (overdue)
        repeat: "none",
      },
      {
        title: "Read Chapter 5",
        description: "\"Atomic Habits\" - Building Better Systems",
        category: "Personal Growth",
        priority: "low",
        dueDate: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
        repeat: "none",
      },
    ];

    sampleReminders.forEach(reminder => {
      const newReminder: Reminder = {
        title: reminder.title,
        description: reminder.description,
        category: reminder.category,
        priority: reminder.priority,
        dueDate: reminder.dueDate,
        repeat: reminder.repeat,
        id: this.currentReminderId++,
        completed: false,
        createdAt: new Date(),
      };
      this.reminders.set(newReminder.id, newReminder);
    });
  }

  async getReminders(): Promise<Reminder[]> {
    return Array.from(this.reminders.values()).filter(r => !r.completed);
  }

  async getRemindersByCategory(category: string): Promise<Reminder[]> {
    return Array.from(this.reminders.values()).filter(r => !r.completed && r.category === category);
  }

  async getReminder(id: number): Promise<Reminder | undefined> {
    return this.reminders.get(id);
  }

  async createReminder(insertReminder: InsertReminder): Promise<Reminder> {
    const id = this.currentReminderId++;
    const reminder: Reminder = {
      title: insertReminder.title,
      description: insertReminder.description,
      category: insertReminder.category,
      priority: insertReminder.priority,
      dueDate: insertReminder.dueDate,
      repeat: insertReminder.repeat,
      id,
      completed: false,
      createdAt: new Date(),
    };
    this.reminders.set(id, reminder);
    return reminder;
  }

  async updateReminder(id: number, updates: Partial<InsertReminder>): Promise<Reminder | undefined> {
    const reminder = this.reminders.get(id);
    if (!reminder) return undefined;

    const updatedReminder = { ...reminder, ...updates };
    this.reminders.set(id, updatedReminder);
    return updatedReminder;
  }

  async deleteReminder(id: number): Promise<boolean> {
    return this.reminders.delete(id);
  }

  async completeReminder(id: number): Promise<boolean> {
    const reminder = this.reminders.get(id);
    if (!reminder) return false;

    // Add to completed reminders
    const completedReminder: CompletedReminder = {
      id: this.currentCompletedId++,
      title: reminder.title,
      category: reminder.category,
      completedAt: new Date(),
      xpEarned: reminder.priority === 'high' ? 10 : reminder.priority === 'medium' ? 5 : 3,
    };
    this.completedRemindersData.set(completedReminder.id, completedReminder);

    // Update user stats
    await this.incrementCompletedToday();

    // Remove the reminder
    this.reminders.delete(id);
    return true;
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  async getUserStats(): Promise<UserStats> {
    return this.userStatsData;
  }

  async updateUserStats(updates: Partial<InsertUserStats>): Promise<UserStats> {
    this.userStatsData = { ...this.userStatsData, ...updates };
    return this.userStatsData;
  }

  async incrementCompletedToday(): Promise<UserStats> {
    const today = new Date();
    const lastCompletion = this.userStatsData.lastCompletionDate;
    
    let streak = this.userStatsData.streak;
    if (lastCompletion) {
      const daysDiff = Math.floor((today.getTime() - lastCompletion.getTime()) / (1000 * 60 * 60 * 24));
      if (daysDiff === 1) {
        streak++; // Continue streak
      } else if (daysDiff > 1) {
        streak = 1; // Reset streak
      }
    } else {
      streak = 1;
    }

    this.userStatsData = {
      ...this.userStatsData,
      completedToday: this.userStatsData.completedToday + 1,
      totalCompleted: this.userStatsData.totalCompleted + 1,
      streak,
      lastCompletionDate: today,
    };
    
    return this.userStatsData;
  }

  async getCompletedReminders(): Promise<CompletedReminder[]> {
    return Array.from(this.completedRemindersData.values())
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime())
      .slice(0, 10); // Return last 10 completed
  }

  async addCompletedReminder(insertCompleted: InsertCompletedReminder): Promise<CompletedReminder> {
    const id = this.currentCompletedId++;
    const completed: CompletedReminder = {
      ...insertCompleted,
      id,
      completedAt: new Date(),
      xpEarned: insertCompleted.xpEarned || 5,
    };
    this.completedRemindersData.set(id, completed);
    return completed;
  }

  async getSuggestions(): Promise<Suggestion[]> {
    const now = new Date();
    const hour = now.getHours();
    
    const suggestions: Suggestion[] = [];

    // Time-based suggestions
    if (hour >= 6 && hour <= 10) {
      suggestions.push({
        id: "morning-meditation",
        title: "Take a 10-minute meditation break",
        description: "Start your day with mindfulness",
        category: "Health & Fitness",
        estimatedDuration: "10 min",
        reason: "Perfect time for morning meditation"
      });
    }

    if (hour >= 12 && hour <= 14) {
      suggestions.push({
        id: "lunch-walk",
        title: "Take a lunch break walk",
        description: "Get some fresh air and movement",
        category: "Health & Fitness",
        estimatedDuration: "15 min",
        reason: "Great time for a midday energy boost"
      });
    }

    // Always available suggestions
    suggestions.push(
      {
        id: "call-family",
        title: "Call a family member",
        description: "Connect with someone you care about",
        category: "Social & Family",
        estimatedDuration: "15 min",
        reason: "Stay connected with loved ones"
      },
      {
        id: "drink-water",
        title: "Drink a glass of water",
        description: "Stay hydrated throughout the day",
        category: "Health & Fitness",
        estimatedDuration: "1 min",
        reason: "Hydration is key to productivity"
      },
      {
        id: "quick-learning",
        title: "Learn something new",
        description: "Read an article or watch an educational video",
        category: "Personal Growth",
        estimatedDuration: "10 min",
        reason: "Continuous learning fuels growth"
      }
    );

    return suggestions.slice(0, 3); // Return top 3 suggestions
  }
}

export const storage = new MemStorage();
