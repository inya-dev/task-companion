import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertReminderSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all reminders
  app.get("/api/reminders", async (req, res) => {
    try {
      const reminders = await storage.getReminders();
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reminders" });
    }
  });

  // Get reminders by category
  app.get("/api/reminders/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const reminders = await storage.getRemindersByCategory(category);
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reminders by category" });
    }
  });

  // Create a new reminder
  app.post("/api/reminders", async (req, res) => {
    try {
      const reminderData = insertReminderSchema.parse(req.body);
      const reminder = await storage.createReminder(reminderData);
      res.status(201).json(reminder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid reminder data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create reminder" });
      }
    }
  });

  // Complete a reminder
  app.post("/api/reminders/:id/complete", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.completeReminder(id);
      
      if (success) {
        res.json({ message: "Reminder completed successfully" });
      } else {
        res.status(404).json({ message: "Reminder not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to complete reminder" });
    }
  });

  // Delete a reminder
  app.delete("/api/reminders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteReminder(id);
      
      if (success) {
        res.json({ message: "Reminder deleted successfully" });
      } else {
        res.status(404).json({ message: "Reminder not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete reminder" });
    }
  });

  // Get categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get user stats
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getUserStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  // Get completed reminders (recent activity)
  app.get("/api/completed", async (req, res) => {
    try {
      const completed = await storage.getCompletedReminders();
      res.json(completed);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch completed reminders" });
    }
  });

  // Get AI suggestions
  app.get("/api/suggestions", async (req, res) => {
    try {
      const suggestions = await storage.getSuggestions();
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch suggestions" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
