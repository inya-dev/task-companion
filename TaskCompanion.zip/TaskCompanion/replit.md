# FutureTask - AI-Powered Reminder Assistant

## Overview

FutureTask is a modern, AI-powered reminder management application built with a full-stack TypeScript architecture. The application features a neon-themed, glassmorphic UI with an interactive pet mascot that celebrates user achievements. It combines traditional reminder functionality with AI-powered suggestions and gamification elements to enhance user engagement.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom neon color scheme and glassmorphic design
- **Build Tool**: Vite for development and production builds
- **Animations**: Framer Motion for smooth UI animations

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Request Handling**: Express middleware for logging, JSON parsing, and error handling
- **Development**: Hot reload via Vite integration in development mode

### Data Layer
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon Database)
- **Schema**: Centralized schema definitions in `/shared/schema.ts`
- **Migrations**: Drizzle Kit for database migrations
- **Storage Abstraction**: Interface-based storage layer with in-memory implementation for development

## Key Components

### Database Schema
- **Reminders**: Core entity with title, description, category, priority, due date, and repeat settings
- **Categories**: Predefined categories with icons and colors for organization
- **User Stats**: Gamification metrics including daily completions, streaks, and total completions
- **Completed Reminders**: Historical record of completed tasks with XP tracking
- **AI Suggestions**: System-generated reminder suggestions

### UI Components
- **Pet Mascot**: Interactive character that celebrates user achievements
- **Stats Dashboard**: Real-time display of user progress and metrics
- **Category Tabs**: Filter reminders by category with count indicators
- **Reminder Cards**: Individual task display with completion actions
- **AI Suggestions**: Intelligent recommendation system for new reminders
- **Recent Activity**: Timeline of completed tasks

### Form Handling
- **React Hook Form**: Form state management with Zod schema validation
- **Modal System**: Overlay-based forms for creating and editing reminders
- **Real-time Validation**: Client-side validation with server-side verification

## Data Flow

1. **Client Requests**: Frontend makes HTTP requests to Express API endpoints
2. **Query Management**: TanStack Query handles caching, synchronization, and optimistic updates
3. **Data Transformation**: Zod schemas ensure type safety between client and server
4. **Storage Layer**: Abstract storage interface allows for different implementations
5. **Real-time Updates**: Event-driven updates for pet mascot celebrations and UI synchronization

## External Dependencies

### Core Technologies
- **@neondatabase/serverless**: Serverless PostgreSQL driver for Neon Database
- **@tanstack/react-query**: Powerful data synchronization for React
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **framer-motion**: Production-ready motion library for React
- **drizzle-orm**: Lightweight TypeScript ORM

### Development Tools
- **@replit/vite-plugin-***: Replit-specific development enhancements
- **tsx**: TypeScript execution engine for development server
- **esbuild**: Fast bundler for production builds

### UI Enhancement
- **class-variance-authority**: Type-safe variant handling for components
- **cmdk**: Command palette implementation
- **embla-carousel-react**: Touch-friendly carousel component
- **date-fns**: Modern date utility library

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite middleware integrated with Express for seamless development
- **Type Checking**: Incremental TypeScript compilation with strict mode
- **Path Aliases**: Configured for clean imports across client, server, and shared code

### Production Build
- **Frontend**: Vite builds static assets to `/dist/public`
- **Backend**: esbuild bundles server code to `/dist/index.js`
- **Static Serving**: Express serves built frontend assets in production
- **Environment Variables**: Database URL and other configs via environment variables

### Database Management
- **Schema Sync**: `drizzle-kit push` for development schema updates
- **Migration Strategy**: File-based migrations in `/migrations` directory
- **Connection**: PostgreSQL via environment variable configuration

The application is designed to be easily deployable to platforms like Vercel, Netlify, or traditional Node.js hosting environments, with the database hosted on Neon or any PostgreSQL-compatible service.