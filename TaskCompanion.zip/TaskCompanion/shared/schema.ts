import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const reminders = pgTable("reminders", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  priority: text("priority").notNull().default("medium"),
  dueDate: timestamp("due_date").notNull(),
  repeat: text("repeat").notNull().default("none"),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
});

export const userStats = pgTable("user_stats", {
  id: serial("id").primaryKey(),
  completedToday: integer("completed_today").notNull().default(0),
  streak: integer("streak").notNull().default(0),
  totalCompleted: integer("total_completed").notNull().default(0),
  lastCompletionDate: timestamp("last_completion_date"),
});

export const completedReminders = pgTable("completed_reminders", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
  xpEarned: integer("xp_earned").notNull().default(5),
});

export const insertReminderSchema = createInsertSchema(reminders).omit({
  id: true,
  completed: true,
  createdAt: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
});

export const insertUserStatsSchema = createInsertSchema(userStats).omit({
  id: true,
});

export const insertCompletedReminderSchema = createInsertSchema(completedReminders).omit({
  id: true,
  completedAt: true,
});

export type InsertReminder = z.infer<typeof insertReminderSchema>;
export type Reminder = typeof reminders.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;
export type UserStats = typeof userStats.$inferSelect;
export type InsertCompletedReminder = z.infer<typeof insertCompletedReminderSchema>;
export type CompletedReminder = typeof completedReminders.$inferSelect;

// Suggestion type for AI recommendations
export interface Suggestion {
  id: string;
  title: string;
  description: string;
  category: string;
  estimatedDuration: string;
  reason: string;
}
