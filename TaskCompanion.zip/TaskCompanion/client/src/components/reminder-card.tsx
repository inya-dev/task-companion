import { motion } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Check, Clock, Repeat, Flag, Bookmark } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Reminder } from "@shared/schema";

interface ReminderCardProps {
  reminder: Reminder;
  onComplete?: () => void;
}

export default function ReminderCard({ reminder, onComplete }: ReminderCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const completeMutation = useMutation({
    mutationFn: (id: number) => apiRequest("POST", `/api/reminders/${id}/complete`),
    onSuccess: () => {
      // Dispatch custom event for pet mascot
      window.dispatchEvent(new CustomEvent('reminder-completed'));
      
      toast({
        title: "Great job! 🎉",
        description: "Reminder completed successfully",
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/completed"] });
      
      onComplete?.();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to complete reminder",
        variant: "destructive",
      });
    },
  });

  const getCategoryColor = (category: string) => {
    const colors = {
      "Health & Fitness": "neon-green",
      "Work & Career": "neon-purple", 
      "Personal Growth": "neon-yellow",
      "Social & Family": "neon-blue",
    };
    return colors[category as keyof typeof colors] || "neon-blue";
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      "Health & Fitness": "🏃",
      "Work & Career": "💼",
      "Personal Growth": "📚",
      "Social & Family": "👥",
    };
    return icons[category as keyof typeof icons] || "📝";
  };

  const getPriorityColor = (priority: string) => {
    const colors = {
      high: "text-red-400",
      medium: "text-yellow-400",
      low: "text-green-400",
    };
    return colors[priority as keyof typeof colors] || "text-gray-400";
  };

  const getTimeStatus = (dueDate: Date) => {
    const now = new Date();
    const due = new Date(dueDate);
    const diffMs = due.getTime() - now.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 0) {
      const overdueDays = Math.floor(Math.abs(diffMins) / (24 * 60));
      return {
        text: overdueDays > 0 ? `${overdueDays} day${overdueDays > 1 ? 's' : ''} overdue` : "Overdue",
        color: "text-red-400"
      };
    } else if (diffMins < 60) {
      return {
        text: `in ${diffMins} mins`,
        color: "text-neon-yellow"
      };
    } else if (diffMins < 24 * 60) {
      const hours = Math.floor(diffMins / 60);
      return {
        text: `in ${hours} hour${hours > 1 ? 's' : ''}`,
        color: "text-neon-blue"
      };
    } else {
      const days = Math.floor(diffMins / (24 * 60));
      return {
        text: `in ${days} day${days > 1 ? 's' : ''}`,
        color: "text-gray-400"
      };
    }
  };

  const timeStatus = getTimeStatus(reminder.dueDate);
  const categoryColor = getCategoryColor(reminder.category);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: 100 }}
      className={`glass rounded-xl p-4 border-l-4 border-${categoryColor} hover:neon-glow transition-all duration-300 cursor-pointer`}
    >
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center mb-2">
            <span className="text-lg mr-2">
              {getCategoryIcon(reminder.category)}
            </span>
            <span className="text-sm text-gray-400">{reminder.category}</span>
            <span className={`ml-auto text-sm ${timeStatus.color}`}>
              {timeStatus.text}
            </span>
          </div>
          
          <h3 className="font-semibold text-white mb-1">
            {reminder.title}
          </h3>
          
          {reminder.description && (
            <p className="text-sm text-gray-400 mb-3">
              {reminder.description}
            </p>
          )}
          
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <div className="flex items-center">
              <Clock className="w-3 h-3 mr-1" />
              <span>{new Date(reminder.dueDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            
            {reminder.repeat !== 'none' && (
              <div className="flex items-center">
                <Repeat className="w-3 h-3 mr-1" />
                <span className="capitalize">{reminder.repeat}</span>
              </div>
            )}
            
            <div className={`flex items-center ${getPriorityColor(reminder.priority)}`}>
              <Flag className="w-3 h-3 mr-1" />
              <span className="capitalize">{reminder.priority} Priority</span>
            </div>
          </div>
        </div>
        
        <Button
          onClick={() => completeMutation.mutate(reminder.id)}
          disabled={completeMutation.isPending}
          size="icon"
          className="ml-4 w-10 h-10 rounded-full border-2 border-neon-green bg-transparent text-neon-green hover:bg-neon-green hover:text-black transition-all duration-300"
        >
          <Check className="w-4 h-4" />
        </Button>
      </div>
    </motion.div>
  );
}
