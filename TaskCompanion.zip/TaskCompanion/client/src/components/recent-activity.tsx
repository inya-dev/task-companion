import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { History, Check, Trophy } from "lucide-react";
import type { CompletedReminder } from "@shared/schema";

export default function RecentActivity() {
  const { data: completedReminders = [], isLoading } = useQuery<CompletedReminder[]>({
    queryKey: ["/api/completed"],
  });

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) {
      return diffDays === 1 ? "1 day ago" : `${diffDays} days ago`;
    } else if (diffHours > 0) {
      return diffHours === 1 ? "1 hour ago" : `${diffHours} hours ago`;
    } else {
      const diffMins = Math.floor(diffMs / (1000 * 60));
      return diffMins <= 1 ? "Just now" : `${diffMins} minutes ago`;
    }
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      "Health & Fitness": "🏃",
      "Work & Career": "💼",
      "Personal Growth": "📚",
      "Social & Family": "👥",
    };
    return icons[category as keyof typeof icons] || "📝";
  };

  if (isLoading) {
    return (
      <div className="glass-dark rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-neon-green mb-4 flex items-center">
          <History className="mr-2" size={20} />
          Recent Completions
        </h3>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center py-2 animate-pulse">
              <div className="w-8 h-8 bg-white/10 rounded-full mr-3"></div>
              <div className="flex-1">
                <div className="h-4 bg-white/10 rounded mb-1"></div>
                <div className="h-3 bg-white/10 rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="glass-dark rounded-2xl p-6">
      <h3 className="text-lg font-semibold text-neon-green mb-4 flex items-center">
        <History className="mr-2" size={20} />
        Recent Completions
      </h3>
      
      <div className="space-y-3">
        {completedReminders.length === 0 ? (
          <div className="text-center text-gray-400 py-4">
            <Trophy className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No completed reminders yet</p>
            <p className="text-xs mt-1">Complete your first reminder to see it here!</p>
          </div>
        ) : (
          completedReminders.map((completion, index) => (
            <motion.div
              key={completion.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-center py-2 hover:bg-white/5 rounded-lg px-2 transition-colors duration-300"
            >
              <div className="w-8 h-8 bg-neon-green/20 rounded-full flex items-center justify-center mr-3">
                <Check className="text-neon-green text-xs" size={12} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm">
                    {getCategoryIcon(completion.category)}
                  </span>
                  <h4 className="text-sm font-medium text-white">
                    {completion.title}
                  </h4>
                </div>
                <p className="text-xs text-gray-400">
                  {getTimeAgo(completion.completedAt)}
                </p>
              </div>
              <div className="text-xs text-neon-green font-medium">
                +{completion.xpEarned} XP
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
