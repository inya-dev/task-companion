import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import type { Category, Reminder } from "@shared/schema";

interface CategoryTabsProps {
  selectedCategory: string | null;
  onCategoryChange: (category: string | null) => void;
}

export default function CategoryTabs({ selectedCategory, onCategoryChange }: CategoryTabsProps) {
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: reminders = [] } = useQuery<Reminder[]>({
    queryKey: ["/api/reminders"],
  });

  const getCategoryCount = (categoryName: string) => {
    return reminders.filter(reminder => reminder.category === categoryName).length;
  };

  const getCategoryIcon = (categoryName: string) => {
    const icons = {
      "Health & Fitness": "🏃",
      "Work & Career": "💼",
      "Personal Growth": "📚",
      "Social & Family": "👥",
    };
    return icons[categoryName as keyof typeof icons] || "📝";
  };

  const getCategoryColor = (categoryName: string) => {
    const colors = {
      "Health & Fitness": "neon-green",
      "Work & Career": "neon-purple",
      "Personal Growth": "neon-yellow",
      "Social & Family": "neon-blue",
    };
    return colors[categoryName as keyof typeof colors] || "neon-blue";
  };

  return (
    <div className="glass-dark rounded-2xl p-6 mb-8">
      <h2 className="text-xl font-semibold mb-4 text-neon-blue">Categories</h2>
      <div className="flex flex-wrap gap-3">
        {/* All Categories Button */}
        <Button
          onClick={() => onCategoryChange(null)}
          variant="outline"
          className={`px-4 py-2 glass border-2 transition-all duration-300 ${
            selectedCategory === null 
              ? 'border-neon-blue bg-neon-blue/10' 
              : 'border-transparent hover:border-neon-blue'
          }`}
        >
          <span className="mr-2">📋</span>
          <span>All Categories</span>
          <span className="ml-2 text-xs bg-neon-blue/20 px-2 py-1 rounded-full">
            {reminders.length}
          </span>
        </Button>

        {categories.map((category) => {
          const count = getCategoryCount(category.name);
          const icon = getCategoryIcon(category.name);
          const color = getCategoryColor(category.name);
          
          return (
            <Button
              key={category.id}
              onClick={() => onCategoryChange(category.name)}
              variant="outline"
              className={`px-4 py-2 glass border-2 transition-all duration-300 ${
                selectedCategory === category.name 
                  ? `border-${color} bg-${color}/10` 
                  : 'border-transparent hover:border-neon-blue'
              }`}
            >
              <span className={`mr-2 text-${color}`}>{icon}</span>
              <span>{category.name}</span>
              <span className={`ml-2 text-xs bg-${color}/20 px-2 py-1 rounded-full`}>
                {count}
              </span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
