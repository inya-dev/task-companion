import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import type { UserStats } from "@shared/schema";

export default function StatsBar() {
  const { data: stats, isLoading } = useQuery<UserStats>({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="glass-dark rounded-xl p-4 text-center animate-pulse">
            <div className="h-8 bg-white/10 rounded mb-2"></div>
            <div className="h-4 bg-white/10 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  const statsData = [
    {
      label: "Completed Today",
      value: stats?.completedToday || 0,
      color: "text-neon-green",
      icon: "✅"
    },
    {
      label: "Total Completed",
      value: stats?.totalCompleted || 0,
      color: "text-neon-yellow",
      icon: "🎯"
    },
    {
      label: "Active Categories",
      value: 4, // Static for now, could be dynamic
      color: "text-neon-blue",
      icon: "📋"
    },
    {
      label: "Day Streak",
      value: stats?.streak || 0,
      color: "text-neon-purple",
      icon: "🔥"
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      {statsData.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="glass-dark rounded-xl p-4 text-center hover:neon-glow transition-all duration-300"
        >
          <div className="text-lg mb-1">{stat.icon}</div>
          <motion.div 
            className={`text-2xl font-bold ${stat.color} mb-1`}
            key={stat.value} // This will trigger animation when value changes
            initial={{ scale: 1.2, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {stat.value}
          </motion.div>
          <div className="text-sm text-gray-400">{stat.label}</div>
        </motion.div>
      ))}
    </div>
  );
}
