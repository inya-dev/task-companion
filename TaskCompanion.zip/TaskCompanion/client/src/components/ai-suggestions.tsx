import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Lightbulb, Clock, Sparkles } from "lucide-react";
import AddReminderModal from "./add-reminder-modal";
import type { Suggestion, InsertReminder } from "@shared/schema";

export default function AISuggestions() {
  const [selectedSuggestion, setSelectedSuggestion] = useState<Suggestion | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { data: suggestions = [], isLoading } = useQuery<Suggestion[]>({
    queryKey: ["/api/suggestions"],
  });

  const handleSuggestionClick = (suggestion: Suggestion) => {
    setSelectedSuggestion(suggestion);
    setIsModalOpen(true);
  };

  const getSuggestionPrefilledData = (): Partial<InsertReminder> | undefined => {
    if (!selectedSuggestion) return undefined;
    
    // Set due date to 1 hour from now
    const dueDate = new Date();
    dueDate.setHours(dueDate.getHours() + 1);
    
    return {
      title: selectedSuggestion.title,
      description: selectedSuggestion.description,
      category: selectedSuggestion.category,
      priority: "medium",
      dueDate,
      repeat: "none",
    };
  };

  const getSuggestionIcon = (title: string) => {
    if (title.toLowerCase().includes('meditat')) return "🧘";
    if (title.toLowerCase().includes('call')) return "📞";
    if (title.toLowerCase().includes('water')) return "💧";
    if (title.toLowerCase().includes('walk')) return "🚶";
    if (title.toLowerCase().includes('learn')) return "🎓";
    return "💡";
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      "Health & Fitness": "neon-green",
      "Work & Career": "neon-purple",
      "Personal Growth": "neon-yellow",
      "Social & Family": "neon-blue",
    };
    return colors[category as keyof typeof colors] || "neon-blue";
  };

  if (isLoading) {
    return (
      <div className="glass-dark rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-neon-blue mb-4 flex items-center">
          <Lightbulb className="text-neon-yellow mr-2" size={20} />
          AI Suggestions
        </h3>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="glass rounded-lg p-3 animate-pulse">
              <div className="h-4 bg-white/10 rounded mb-2"></div>
              <div className="h-3 bg-white/10 rounded w-3/4"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="glass-dark rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-neon-blue mb-4 flex items-center">
          <Lightbulb className="text-neon-yellow mr-2" size={20} />
          AI Suggestions
        </h3>
        
        <div className="space-y-3">
          {suggestions.length === 0 ? (
            <div className="text-center text-gray-400 py-4">
              <Sparkles className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No suggestions available right now</p>
            </div>
          ) : (
            suggestions.map((suggestion, index) => (
              <motion.div
                key={suggestion.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => handleSuggestionClick(suggestion)}
                className="glass rounded-lg p-3 hover:bg-white/20 transition-colors duration-300 cursor-pointer group"
              >
                <div className="flex items-start">
                  <div className="text-lg mr-3 group-hover:scale-110 transition-transform">
                    {getSuggestionIcon(suggestion.title)}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-white group-hover:text-neon-blue transition-colors">
                      {suggestion.title}
                    </h4>
                    <p className="text-xs text-gray-400 mt-1">
                      {suggestion.reason}
                    </p>
                    <div className="flex items-center mt-2 gap-2">
                      <span className={`text-xs bg-${getCategoryColor(suggestion.category)}/20 text-${getCategoryColor(suggestion.category)} px-2 py-1 rounded`}>
                        {suggestion.category}
                      </span>
                      <div className="flex items-center text-xs text-gray-500">
                        <Clock className="w-3 h-3 mr-1" />
                        {suggestion.estimatedDuration}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>

      <AddReminderModal
        open={isModalOpen}
        onOpenChange={(open) => {
          setIsModalOpen(open);
          if (!open) setSelectedSuggestion(null);
        }}
        prefilledData={getSuggestionPrefilledData()}
      />
    </>
  );
}
