import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import type { UserStats } from "@shared/schema";

interface PetMascotProps {
  onCelebrate?: () => void;
}

export default function PetMascot({ onCelebrate }: PetMascotProps) {
  const [isClapping, setIsClapping] = useState(false);
  const [message, setMessage] = useState("Ready to help!");
  
  const { data: stats } = useQuery<UserStats>({
    queryKey: ["/api/stats"],
  });

  const celebrateCompletion = () => {
    setIsClapping(true);
    setMessage("Amazing work! 🎉");
    
    setTimeout(() => {
      setIsClapping(false);
      const messages = [
        "Ready to help!",
        "You're doing great!",
        "Keep it up!",
        "I'm proud of you!",
        `${stats?.streak || 0} day streak! 🔥`
      ];
      setMessage(messages[Math.floor(Math.random() * messages.length)]);
    }, 2000);
    
    onCelebrate?.();
  };

  // Listen for completion events globally
  useEffect(() => {
    const handleCompletion = () => {
      celebrateCompletion();
    };

    window.addEventListener('reminder-completed', handleCompletion);
    return () => window.removeEventListener('reminder-completed', handleCompletion);
  }, [stats]);

  return (
    <div className="flex flex-col items-center">
      <div className="relative">
        {/* Main pet mascot */}
        <motion.div
          animate={{
            y: isClapping ? [0, -10, 0] : [0, -5, 0],
            scale: isClapping ? [1, 1.2, 1] : 1,
          }}
          transition={{
            duration: isClapping ? 0.6 : 3,
            repeat: isClapping ? 0 : Infinity,
            ease: "easeInOut",
          }}
          className="w-16 h-16 bg-gradient-to-br from-neon-purple to-neon-blue rounded-full flex items-center justify-center"
        >
          <div className="text-2xl text-white">🤖</div>
        </motion.div>
        
        {/* Celebration particles */}
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ 
            opacity: isClapping ? 1 : 0,
            scale: isClapping ? 1 : 0,
          }}
          transition={{ duration: 0.3 }}
          className="absolute -top-2 -right-2"
        >
          <div className="w-6 h-6 bg-neon-green rounded-full flex items-center justify-center">
            <div className="text-xs text-white">👏</div>
          </div>
        </motion.div>
        
        {/* Floating sparkles when celebrating */}
        {isClapping && (
          <>
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ 
                  opacity: 1, 
                  scale: 0,
                  x: 0,
                  y: 0,
                }}
                animate={{ 
                  opacity: 0,
                  scale: 1,
                  x: Math.random() * 60 - 30,
                  y: Math.random() * 60 - 30,
                }}
                transition={{ 
                  duration: 1.5,
                  delay: i * 0.1,
                }}
                className="absolute top-1/2 left-1/2 w-2 h-2 bg-neon-yellow rounded-full"
              />
            ))}
          </>
        )}
      </div>
      
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-xs text-gray-400 mt-2 text-center max-w-24"
      >
        {message}
      </motion.div>
    </div>
  );
}
