import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertReminderSchema } from "@shared/schema";
import type { InsertReminder, Category } from "@shared/schema";
import { z } from "zod";

const formSchema = insertReminderSchema.extend({
  dueDate: z.string().min(1, "Due date is required"),
  dueTime: z.string().min(1, "Due time is required"),
});

type FormData = z.infer<typeof formSchema>;

interface AddReminderModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  prefilledData?: Partial<InsertReminder>;
}

export default function AddReminderModal({ open, onOpenChange, prefilledData }: AddReminderModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: prefilledData?.title || "",
      description: prefilledData?.description || "",
      category: prefilledData?.category || "",
      priority: prefilledData?.priority || "medium",
      dueDate: "",
      dueTime: "",
      repeat: prefilledData?.repeat || "none",
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertReminder) => apiRequest("POST", "/api/reminders", data),
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Reminder created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      onOpenChange(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create reminder",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    // Combine date and time into a Date object
    const dueDateTime = new Date(`${data.dueDate}T${data.dueTime}`);
    
    const reminderData: InsertReminder = {
      title: data.title,
      description: data.description,
      category: data.category,
      priority: data.priority,
      dueDate: dueDateTime,
      repeat: data.repeat,
    };

    createMutation.mutate(reminderData);
  };

  const handleClose = () => {
    form.reset();
    onOpenChange(false);
  };

  // Set default date to today and time to current hour + 1
  const getDefaultDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  const getDefaultTime = () => {
    const now = new Date();
    now.setHours(now.getHours() + 1);
    return now.toTimeString().slice(0, 5);
  };

  // Set defaults when modal opens
  React.useEffect(() => {
    if (open && !form.getValues().dueDate) {
      form.setValue('dueDate', getDefaultDate());
      form.setValue('dueTime', getDefaultTime());
    }
  }, [open, form]);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="glass-dark border border-white/20 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-neon-blue text-xl">Add New Reminder</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Title</FormLabel>
                  <FormControl>
                    <Input 
                      {...field}
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-neon-blue"
                      placeholder="Enter reminder title"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field}
                      value={field.value || ""}
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-neon-blue resize-none"
                      placeholder="Add description (optional)"
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-white/10 border-white/20 text-white focus:border-neon-blue">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-dark-card border-white/20">
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.name} className="text-white hover:bg-white/10">
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Priority</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-white/10 border-white/20 text-white focus:border-neon-blue">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-dark-card border-white/20">
                        <SelectItem value="low" className="text-white hover:bg-white/10">Low</SelectItem>
                        <SelectItem value="medium" className="text-white hover:bg-white/10">Medium</SelectItem>
                        <SelectItem value="high" className="text-white hover:bg-white/10">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Date</FormLabel>
                    <FormControl>
                      <Input 
                        {...field}
                        type="date"
                        className="bg-white/10 border-white/20 text-white focus:border-neon-blue"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dueTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Time</FormLabel>
                    <FormControl>
                      <Input 
                        {...field}
                        type="time"
                        className="bg-white/10 border-white/20 text-white focus:border-neon-blue"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="repeat"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Repeat</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white focus:border-neon-blue">
                        <SelectValue placeholder="Select repeat option" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-dark-card border-white/20">
                      <SelectItem value="none" className="text-white hover:bg-white/10">No Repeat</SelectItem>
                      <SelectItem value="daily" className="text-white hover:bg-white/10">Daily</SelectItem>
                      <SelectItem value="weekly" className="text-white hover:bg-white/10">Weekly</SelectItem>
                      <SelectItem value="monthly" className="text-white hover:bg-white/10">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-3 pt-4">
              <Button 
                type="submit"
                disabled={createMutation.isPending}
                className="flex-1 bg-neon-blue hover:bg-neon-blue/80 text-black font-medium"
              >
                {createMutation.isPending ? "Creating..." : "Create Reminder"}
              </Button>
              <Button 
                type="button"
                variant="outline"
                onClick={handleClose}
                className="flex-1 glass border-white/20 hover:bg-white/10 text-white"
              >
                Cancel
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
