import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PetMascot from "../components/pet-mascot";
import StatsBar from "../components/stats-bar";
import CategoryTabs from "../components/category-tabs";
import ReminderCard from "../components/reminder-card";
import AddReminderModal from "../components/add-reminder-modal";
import AISuggestions from "../components/ai-suggestions";
import RecentActivity from "../components/recent-activity";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import type { Reminder } from "@shared/schema";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const { data: reminders = [], isLoading: remindersLoading } = useQuery<Reminder[]>({
    queryKey: ["/api/reminders"],
  });

  const filteredReminders = selectedCategory 
    ? reminders.filter(reminder => reminder.category === selectedCategory)
    : reminders;

  const handleReminderComplete = () => {
    // This will be handled by the ReminderCard component
    // and will trigger the pet celebration
  };

  if (remindersLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-neon-blue text-xl">Loading your reminders...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-6xl">
      {/* Header Section */}
      <header className="glass-dark rounded-2xl p-6 mb-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-neon-blue/20 to-neon-purple/20"></div>
        <div className="relative flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-neon-blue mb-2">FutureTask</h1>
            <p className="text-gray-400">Your AI-powered reminder assistant</p>
          </div>
          <PetMascot />
        </div>
      </header>

      {/* Quick Stats */}
      <StatsBar />

      {/* Category Tabs */}
      <CategoryTabs 
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
      />

      {/* Main Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Active Reminders */}
        <div className="lg:col-span-2">
          <div className="glass-dark rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-neon-blue">Active Reminders</h2>
              <Button 
                onClick={() => setIsAddModalOpen(true)}
                className="bg-neon-blue hover:bg-neon-blue/80 text-black font-medium"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Reminder
              </Button>
            </div>
            
            {/* Reminder Cards */}
            <div className="space-y-4">
              {filteredReminders.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    {selectedCategory 
                      ? `No reminders in ${selectedCategory} category`
                      : "No active reminders"
                    }
                  </div>
                  <Button 
                    onClick={() => setIsAddModalOpen(true)}
                    variant="outline"
                    className="border-neon-blue text-neon-blue hover:bg-neon-blue/10"
                  >
                    Create your first reminder
                  </Button>
                </div>
              ) : (
                filteredReminders.map(reminder => (
                  <ReminderCard 
                    key={reminder.id} 
                    reminder={reminder}
                    onComplete={handleReminderComplete}
                  />
                ))
              )}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <AISuggestions />
          <RecentActivity />
        </div>
      </div>

      {/* Add Reminder Modal */}
      <AddReminderModal 
        open={isAddModalOpen}
        onOpenChange={setIsAddModalOpen}
      />
    </div>
  );
}
